import { Heart } from 'lucide-react';

const footerLinks = {
  menu: [
    { label: 'Catering Prasmanan', href: '#menu' },
    { label: 'Nasi Box', href: '#menu' },
    { label: 'Frozen Dim Sum', href: '#menu' },
    { label: 'Frozen Snack', href: '#menu' },
  ],
  perusahaan: [
    { label: 'Tentang Kami', href: '#tentang' },
    { label: 'Keunggulan', href: '#keunggulan' },
    { label: 'Testimoni', href: '#testimoni' },
    { label: 'Kontak', href: '#kontak' },
  ],
};

export default function Footer() {
  return (
    <footer id="kontak" className="bg-charcoal-900 pt-16 sm:pt-20 pb-6">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8 pb-12 border-b border-charcoal-800">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-terracotta-500 flex items-center justify-center">
                <span className="text-white font-serif text-xl font-bold">T</span>
              </div>
              <span className="font-serif text-2xl text-white tracking-wide">Tameroll</span>
            </div>
            <p className="text-charcoal-400 text-sm leading-relaxed mb-6 max-w-xs">
              Premium Catering & Frozen Food untuk setiap momen spesial Anda. Cita rasa restoran, kualitas terjamin.
            </p>
            {/* Social */}
            <div className="flex gap-3">
              {[
                { label: 'Instagram', icon: (
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
                )},
                { label: 'TikTok', icon: (
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 00-.79-.05A6.34 6.34 0 003.15 15.2a6.34 6.34 0 0010.86 4.48 6.28 6.28 0 001.82-4.48V8.73a8.32 8.32 0 004.76 1.49V6.77a4.85 4.85 0 01-1-.08z"/></svg>
                )},
                { label: 'Facebook', icon: (
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                )},
              ].map((social) => (
                <a
                  key={social.label}
                  href="#"
                  aria-label={social.label}
                  className="w-10 h-10 rounded-xl bg-charcoal-800 hover:bg-terracotta-500 flex items-center justify-center text-charcoal-400 hover:text-white transition-all duration-300"
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Links - Menu */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Menu</h4>
            <ul className="space-y-3">
              {footerLinks.menu.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-charcoal-400 hover:text-terracotta-400 text-sm transition-colors duration-200">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Links - Company */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Perusahaan</h4>
            <ul className="space-y-3">
              {footerLinks.perusahaan.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-charcoal-400 hover:text-terracotta-400 text-sm transition-colors duration-200">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Promo & Info</h4>
            <p className="text-charcoal-400 text-sm mb-4">
              Dapatkan info promo dan menu terbaru langsung di inbox Anda.
            </p>
            <form onSubmit={(e) => e.preventDefault()} className="flex gap-2">
              <input
                type="email"
                placeholder="Email Anda"
                className="flex-1 px-4 py-2.5 rounded-xl bg-charcoal-800 border border-charcoal-700 text-white text-sm placeholder:text-charcoal-500 focus:outline-none focus:border-terracotta-500 transition-colors"
              />
              <button
                type="submit"
                className="px-4 py-2.5 bg-terracotta-500 hover:bg-terracotta-600 text-white text-sm font-semibold rounded-xl transition-colors"
              >
                Kirim
              </button>
            </form>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-charcoal-500 text-xs flex items-center gap-1">
            © {new Date().getFullYear()} Tameroll. Made with <Heart size={12} className="text-terracotta-500 fill-terracotta-500" /> All rights reserved.
          </p>
          <div className="flex gap-4">
            <a href="#" className="text-charcoal-500 hover:text-charcoal-300 text-xs transition-colors">Privacy Policy</a>
            <a href="#" className="text-charcoal-500 hover:text-charcoal-300 text-xs transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
